
'use strict';

/* ═══════════════════════════════════════════════════════════════
   1. CAROUSEL DATA
   ═══════════════════════════════════════════════════════════════ */
const SLIDES = [
  {
    src: 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=900&q=85',
    thumb: 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=180&q=70',
    alt: 'HDPE pipe installation – workers laying orange pipes on site'
  },
  {
    src: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=900&q=85',
    thumb: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=180&q=70',
    alt: 'Industrial pipe infrastructure overhead view'
  },
  {
    src: 'https://images.unsplash.com/photo-1621905252507-b35492cc74b4?w=900&q=85',
    thumb: 'https://images.unsplash.com/photo-1621905252507-b35492cc74b4?w=180&q=70',
    alt: 'Pipe manufacturing floor'
  },
  {
    src: 'https://images.unsplash.com/photo-1565193566173-7a0ee3dbe261?w=900&q=85',
    thumb: 'https://images.unsplash.com/photo-1565193566173-7a0ee3dbe261?w=180&q=70',
    alt: 'HDPE coil pipes in production'
  },
  {
    src: 'https://images.unsplash.com/photo-1530124566582-a618bc2615dc?w=900&q=85',
    thumb: 'https://images.unsplash.com/photo-1530124566582-a618bc2615dc?w=180&q=70',
    alt: 'Industrial pipeline system installation'
  }
];

/* ═══════════════════════════════════════════════════════════════
   2. DOM REFERENCES
   ═══════════════════════════════════════════════════════════════ */
const mainImg       = document.getElementById('mainImg');
const carouselFrame = document.getElementById('carouselFrame');
const thumbsContainer = document.getElementById('thumbsContainer');
const prevBtn       = document.getElementById('prevBtn');
const nextBtn       = document.getElementById('nextBtn');
const zoomLens      = document.getElementById('zoomLens');
const zoomResult    = document.getElementById('zoomResult');
const stickyBar     = document.getElementById('stickyBar');
const hamburger     = document.getElementById('hamburger');
const navLinks      = document.getElementById('navLinks');

/* ═══════════════════════════════════════════════════════════════
   3. CAROUSEL
   ═══════════════════════════════════════════════════════════════ */
let currentSlide = 0;

/**
 * Navigate to a given slide index.
 * Wraps around at both ends.
 */
function goToSlide(index) {
  const total = SLIDES.length;
  currentSlide = ((index % total) + total) % total;  // safe modulo

  // Fade out → swap src → fade in
  mainImg.style.opacity = '0';
  setTimeout(() => {
    mainImg.src = SLIDES[currentSlide].src;
    mainImg.alt = SLIDES[currentSlide].alt;
    mainImg.style.opacity = '1';
    // Update zoom background source
    zoomResult.style.backgroundImage = `url('${SLIDES[currentSlide].src}')`;
  }, 180);

  // Sync thumbnails
  const thumbBtns = thumbsContainer.querySelectorAll('.carousel__thumb');
  thumbBtns.forEach((btn, i) => {
    const isActive = i === currentSlide;
    btn.classList.toggle('is-active', isActive);
    btn.setAttribute('aria-selected', String(isActive));
  });

  // Announce to screen readers
  carouselFrame.setAttribute('aria-label', `Slide ${currentSlide + 1} of ${total}: ${SLIDES[currentSlide].alt}`);
}

// Smooth image fade via CSS transition on the <img>
mainImg.style.transition = 'opacity .18s ease';

// Arrows
prevBtn.addEventListener('click', () => goToSlide(currentSlide - 1));
nextBtn.addEventListener('click', () => goToSlide(currentSlide + 1));

// Thumbnail clicks (event delegation)
thumbsContainer.addEventListener('click', (e) => {
  const btn = e.target.closest('.carousel__thumb');
  if (btn) goToSlide(Number(btn.dataset.index));
});

// Keyboard: ←/→ arrows
document.addEventListener('keydown', (e) => {
  if (e.key === 'ArrowLeft')  goToSlide(currentSlide - 1);
  if (e.key === 'ArrowRight') goToSlide(currentSlide + 1);
});

// Touch swipe
let touchStartX = 0;
carouselFrame.addEventListener('touchstart', (e) => {
  touchStartX = e.changedTouches[0].screenX;
}, { passive: true });
carouselFrame.addEventListener('touchend', (e) => {
  const dx = e.changedTouches[0].screenX - touchStartX;
  if (Math.abs(dx) > 40) goToSlide(currentSlide + (dx < 0 ? 1 : -1));
});

/* ═══════════════════════════════════════════════════════════════
   4. ZOOM ON HOVER (desktop only)
   Uses a magnifier-lens technique:
   – a small "lens" square moves under the cursor inside the main image
   – a "result" div to the right shows the zoomed area via background-position
   ═══════════════════════════════════════════════════════════════ */
const ZOOM_FACTOR = 3;  // 3× magnification

// Initialise result background
zoomResult.style.backgroundImage = `url('${SLIDES[0].src}')`;
zoomResult.style.backgroundRepeat = 'no-repeat';

function handleZoomMove(e) {
  // Only run on non-touch (pointer has width > 0)
  if (e.pointerType === 'touch') return;

  const frameRect = carouselFrame.getBoundingClientRect();
  const lensW = zoomLens.offsetWidth;
  const lensH = zoomLens.offsetHeight;
  const frameW = frameRect.width;
  const frameH = frameRect.height;

  // Cursor relative to frame
  let cx = e.clientX - frameRect.left;
  let cy = e.clientY - frameRect.top;

  // Lens top-left, clamped inside frame
  let lx = cx - lensW / 2;
  let ly = cy - lensH / 2;
  lx = Math.max(0, Math.min(frameW - lensW, lx));
  ly = Math.max(0, Math.min(frameH - lensH, ly));

  // Position the lens
  zoomLens.style.left = lx + 'px';
  zoomLens.style.top  = ly + 'px';
  zoomLens.style.display = 'block';

  // Zoom result background size = frame * zoom factor
  const bgW = frameW * ZOOM_FACTOR;
  const bgH = frameH * ZOOM_FACTOR;

  // Background position: lens pos * zoom factor (negative = pan left/up)
  const bgX = -(lx * ZOOM_FACTOR);
  const bgY = -(ly * ZOOM_FACTOR);

  zoomResult.style.backgroundSize     = `${bgW}px ${bgH}px`;
  zoomResult.style.backgroundPosition = `${bgX}px ${bgY}px`;
  zoomResult.style.display            = 'block';
}

function handleZoomLeave() {
  zoomLens.style.display   = 'none';
  zoomResult.style.display = 'none';
}

// Attach only for pointer (covers mouse; excluded for touch via pointerType check)
carouselFrame.addEventListener('pointermove', handleZoomMove);
carouselFrame.addEventListener('pointerleave', handleZoomLeave);

/* ═══════════════════════════════════════════════════════════════
   5. STICKY BAR
   – appears when user scrolls past hero fold (nav height + ~100px)
   – uses a velocity check to also hide when scrolling back up
   ═══════════════════════════════════════════════════════════════ */
const NAV_HEIGHT = 64;   // matches --nav-h in CSS
// Threshold: sticky bar appears after user scrolls past the nav + 80px buffer
const STICKY_THRESHOLD = NAV_HEIGHT + 80;

let lastScrollY = window.scrollY;

function onScroll() {
  const currentY  = window.scrollY;
  const scrollDown = currentY > lastScrollY;

  if (currentY > STICKY_THRESHOLD) {
    // Show when scrolled far enough; hide if user is scrolling back up
    if (scrollDown) {
      stickyBar.classList.add('is-visible');
      stickyBar.setAttribute('aria-hidden', 'false');
    } else {
      stickyBar.classList.remove('is-visible');
      stickyBar.setAttribute('aria-hidden', 'true');
    }
  } else {
    stickyBar.classList.remove('is-visible');
    stickyBar.setAttribute('aria-hidden', 'true');
  }

  lastScrollY = currentY;
}

window.addEventListener('scroll', onScroll, { passive: true });

/* ═══════════════════════════════════════════════════════════════
   6. HAMBURGER MENU (mobile)
   ═══════════════════════════════════════════════════════════════ */
hamburger.addEventListener('click', () => {
  const isOpen = navLinks.classList.toggle('is-open');
  hamburger.classList.toggle('is-open', isOpen);
  hamburger.setAttribute('aria-expanded', String(isOpen));
  // Prevent body scroll when menu open
  document.body.style.overflow = isOpen ? 'hidden' : '';
});

// Close when a link is tapped
navLinks.querySelectorAll('a').forEach((link) => {
  link.addEventListener('click', () => {
    navLinks.classList.remove('is-open');
    hamburger.classList.remove('is-open');
    hamburger.setAttribute('aria-expanded', 'false');
    document.body.style.overflow = '';
  });
});

// Close on ESC key
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && navLinks.classList.contains('is-open')) {
    navLinks.classList.remove('is-open');
    hamburger.classList.remove('is-open');
    hamburger.setAttribute('aria-expanded', 'false');
    document.body.style.overflow = '';
    hamburger.focus();
  }
});

/* ═══════════════════════════════════════════════════════════════
   7. SCROLL-TRIGGERED ANIMATIONS (Intersection Observer)
   Feature cards and spec rows animate in as they enter viewport.
   ═══════════════════════════════════════════════════════════════ */
const animTargets = document.querySelectorAll('.feat-card, .specs-table tbody tr');

const ioOptions = { threshold: 0.12 };
const io = new IntersectionObserver((entries) => {
  entries.forEach((entry, idx) => {
    if (entry.isIntersecting) {
      // Stagger delay based on order within observed set
      const delay = Array.from(animTargets).indexOf(entry.target) * 50;
      entry.target.style.animationDelay = `${delay}ms`;
      entry.target.style.animation = `fadeUp .45s ease both`;
      io.unobserve(entry.target);
    }
  });
}, ioOptions);

animTargets.forEach((el) => {
  el.style.opacity = '0';
  io.observe(el);
});

/* ═══════════════════════════════════════════════════════════════
   8. SMOOTH SCROLL – "View Technical Specs" button
   ═══════════════════════════════════════════════════════════════ */
document.querySelectorAll('.pinfo__cta .btn--outline').forEach((btn) => {
  btn.addEventListener('click', () => {
    const specs = document.getElementById('technicalSpecs');
    if (specs) specs.scrollIntoView({ behavior: 'smooth', block: 'start' });
  });
});

/* ═══════════════════════════════════════════════════════════════
   INIT
   ═══════════════════════════════════════════════════════════════ */
// Make sure first slide is primed
goToSlide(0);
